// VARIÁVEIS GLOBAIS
let horta = []; // Array para guardar os "quadrados" da nossa horta
let tamanhoCelula = 50; // Tamanho de cada quadrado da horta
let colunas;
let linhas;

let dinheiro = 100; // Dinheiro inicial do jogador
let tempoJogo = 0; // Contador de tempo para o crescimento das plantas
let taxaCrescimento = 1; // Quão rápido as plantas crescem (em "unidades de tempo")

let estadoJogo = 'menu'; // 'menu', 'jogando'

// --- FUNÇÃO setup() ---
// É executada uma vez quando o programa inicia
function setup() {
  createCanvas(800, 600); // Cria uma tela de 800 por 600 pixels
  
  colunas = floor(width / tamanhoCelula);
  linhas = floor(height / tamanhoCelula);
  
  // Inicializa a horta com "terra vazia"
  for (let i = 0; i < colunas; i++) {
    horta[i] = [];
    for (let j = 0; j < linhas; j++) {
      horta[i][j] = {
        tipo: 'terra', // 'terra', 'semente', 'planta'
        estagioCrescimento: 0, // 0 = semente, 1-3 = crescendo, 4 = pronta para colher
        tempoPlantado: 0 // Tempo em que a semente foi plantada
      };
    }
  }
  
  textAlign(CENTER, CENTER);
  textSize(24);
}

// --- FUNÇÃO draw() ---
// É executada continuamente (loop)
function draw() {
  background(139, 69, 19); // Cor de fundo: marrom (terra)

  if (estadoJogo === 'menu') {
    desenharMenu();
  } else if (estadoJogo === 'jogando') {
    desenharHorta();
    desenharUI(); // Desenha a interface do usuário (dinheiro, tempo)
    atualizarTempo(); // Atualiza o tempo do jogo e o crescimento das plantas
  }
}

// --- FUNÇÕES DE DESENHO ---

function desenharMenu() {
  background(50, 150, 200); // Azul claro para o menu
  fill(255);
  text("Minha Pequena Horta Rural", width / 2, height / 2 - 50);
  text("Clique para Começar", width / 2, height / 2);
}

function desenharHorta() {
  for (let i = 0; i < colunas; i++) {
    for (let j = 0; j < linhas; j++) {
      let x = i * tamanhoCelula;
      let y = j * tamanhoCelula;

      noStroke();
      
      // Desenha o tipo de solo/planta
      if (horta[i][j].tipo === 'terra') {
        fill(139, 69, 19); // Marrom escuro para terra
      } else if (horta[i][j].tipo === 'semente') {
        fill(100, 50, 0); // Marrom avermelhado para semente
        rect(x + tamanhoCelula * 0.4, y + tamanhoCelula * 0.4, tamanhoCelula * 0.2, tamanhoCelula * 0.2); // Ponto pequeno
      } else if (horta[i][j].tipo === 'planta') {
        let estagio = horta[i][j].estagioCrescimento;
        if (estagio === 1) { // Pequena muda
          fill(100, 200, 50); 
          rect(x + tamanhoCelula * 0.4, y + tamanhoCelula * 0.6, tamanhoCelula * 0.2, tamanhoCelula * 0.2);
        } else if (estagio === 2) { // Planta média
          fill(50, 180, 50);
          rect(x + tamanhoCelula * 0.3, y + tamanhoCelula * 0.5, tamanhoCelula * 0.4, tamanhoCelula * 0.4);
        } else if (estagio === 3) { // Planta grande
          fill(0, 160, 0);
          rect(x + tamanhoCelula * 0.2, y + tamanhoCelula * 0.4, tamanhoCelula * 0.6, tamanhoCelula * 0.6);
        } else if (estagio === 4) { // Pronta para colher! (ex: tomate vermelho)
          fill(255, 0, 0); 
          ellipse(x + tamanhoCelula / 2, y + tamanhoCelula / 2, tamanhoCelula * 0.7, tamanhoCelula * 0.7);
        }
      }
      
      // Desenha as bordas das células
      stroke(0); // Cor da borda preta
      strokeWeight(1); // Espessura da borda
      rect(x, y, tamanhoCelula, tamanhoCelula);
    }
  }
}

function desenharUI() {
  fill(255); // Cor do texto branco
  textSize(20);
  text("Dinheiro: $" + dinheiro, 100, 30);
  text("Tempo: " + floor(tempoJogo / 60) + " segundos", width - 150, 30); // 60 frames = 1 segundo
}

// --- FUNÇÕES DE LÓGICA DO JOGO ---

function mousePressed() {
  if (estadoJogo === 'menu') {
    estadoJogo = 'jogando';
    return; // Sai da função para não processar clique como plantio
  }

  // Calcula qual célula foi clicada
  let i = floor(mouseX / tamanhoCelula);
  let j = floor(mouseY / tamanhoCelula);

  // Garante que o clique está dentro da horta
  if (i >= 0 && i < colunas && j >= 0 && j < linhas) {
    if (horta[i][j].tipo === 'terra' && dinheiro >= 10) { // Custo da semente
      horta[i][j].tipo = 'semente';
      horta[i][j].tempoPlantado = tempoJogo; // Marca o tempo que foi plantado
      dinheiro -= 10;
    } else if (horta[i][j].tipo === 'planta' && horta[i][j].estagioCrescimento === 4) {
      // Se a planta está pronta para colher, colhe
      horta[i][j].tipo = 'terra'; // Volta a ser terra vazia
      horta[i][j].estagioCrescimento = 0;
      dinheiro += 50; // Ganha dinheiro pela colheita
    }
  }
}

function atualizarTempo() {
  if (frameCount % 60 === 0) { // A cada 60 frames (aprox. 1 segundo)
    tempoJogo++;

    // Atualiza o crescimento das plantas
    for (let i = 0; i < colunas; i++) {
      for (let j = 0; j < linhas; j++) {
        if (horta[i][j].tipo === 'semente' || horta[i][j].tipo === 'planta') {
          // Se a planta está pronta para colher, não cresce mais
          if (horta[i][j].estagioCrescimento < 4) { 
            let tempoPassado = tempoJogo - horta[i][j].tempoPlantado;
            // Cresce a cada X segundos (ajuste 'taxaCrescimento' para mudar)
            if (tempoPassado % (60 * taxaCrescimento) === 0 && tempoPassado > 0) { 
               horta[i][j].estagioCrescimento++;
               if (horta[i][j].estagioCrescimento >= 1) { // A partir do estágio 1, vira 'planta'
                 horta[i][j].tipo = 'planta';
               }
            }
          }
        }
      }
    }
  }
}
        
      
    